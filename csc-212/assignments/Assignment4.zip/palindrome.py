"""A palindrome is a word that is the same with each character reversed."""
from Stack import Stack


def is_palindrome2(word):
    """Receives a wording and appends each character onto a Stack, then, each
    element is popped off of the stack. If the word is a palindrome the
    characters should be in the same sequence as the original wording.
    """
    # Assure uniformity
    word = word.lower()
    char_stack = Stack()
    for char in word:
        char_stack.push(char)
    for elem in range(char_stack.size()):
        if char_stack.pop() == word[elem]:
            continue
        else:
            return False
    return True

    # Comment out another adhd solution
    # if ''.join(char_stack.view_all_reversed()) == word:


def is_palindrome(word):
    """Receives a word and reverses that wording checking for palindromes."""
    word = word.lower()
    if word == ''.join(reversed(word)):
        return True
    return False


def main():
    """Runs tests on the defined functions."""
    print(is_palindrome('level'))
    print(is_palindrome('cat'))
    print(is_palindrome2(input('Enter a word: ')))


if __name__ == '__main__':
    main()
